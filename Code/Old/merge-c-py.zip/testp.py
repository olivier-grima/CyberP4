import somme

a = 0.0;
print("test");
print(a);
print("appel fonction");

print("res : ");
print(somme.sommefunc(a));

